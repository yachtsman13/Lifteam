@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo.
echo   ================================================
echo    LiftTeam — Push to GitHub
echo   ================================================
echo.

:: Проверка Git
where git >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo   [ERROR] Git не найден. Установите: https://git-scm.com/download/win
    pause
    exit /b 1
)

:: Проверка .git
if not exist ".git" (
    echo   [1/6] Инициализация репозитория...
    git init
    git remote add origin https://github.com/yachtsman13/Lifteam.git 2>nul || git remote set-url origin https://github.com/yachtsman13/Lifteam.git
) else (
    echo   [OK] Git репозиторий найден
    git remote -v | findstr "yachtsman13/Lifteam" >nul
    if %ERRORLEVEL% NEQ 0 (
        echo   [FIX] Исправляем remote URL...
        git remote remove origin 2>nul
        git remote add origin https://github.com/yachtsman13/Lifteam.git
    )
)

:: Проверка user.name и user.email
git config user.name >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo   [2/6] Настройка Git identity...
    git config user.name "yachtsman13"
    git config user.email "yachtsman13@github.com"
) else (
    echo   [OK] Git identity настроена
)

:: Проверка safe.directory
git config --global --get-regexp safe.directory | findstr /C:"%~dp0" >nul
if %ERRORLEVEL% NEQ 0 (
    echo   [3/6] Добавление safe.directory...
    git config --global --add safe.directory "%~dp0"
)

:: Добавление файлов
echo   [4/6] Добавление файлов...
git add -A

:: Коммит
echo   [5/6] Создание коммита...
git commit -m "LiftTeam v2.2.3 update" 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo   [INFO] Нет изменений для коммита
)

:: Пуш
echo   [6/6] Отправка на GitHub...
echo.
echo   Введите логин GitHub и Personal Access Token когда запросит.
echo   (или настройте credential.helper для сохранения)
echo.
git push -u origin main --force

if %ERRORLEVEL% EQU 0 (
    echo.
    echo   [OK] Успешно отправлено на https://github.com/yachtsman13/Lifteam
) else (
    echo.
    echo   [ERROR] Ошибка отправки. Возможные причины:
    echo     - Неверный логин/токен
    echo     - Нет доступа к репозиторию
    echo     - Нет интернет-соединения
    echo.
    echo   Решение: создайте Personal Access Token:
    echo     https://github.com/settings/tokens ^> Generate new token
    echo     Права: repo (полный доступ к репозиториям)
)

echo.
pause
