# LiftTeam v2.2.4.4.3.2

Система управления заказами на ремонт лифтов и складом радиодеталей.

## Быстрый старт

### Windows
Двойной клик по `start.bat` или `lifteam_launcher.py`

### Linux / macOS
```bash
./start.sh
```

### Docker
```bash
docker-compose up -d
```

## Логин по умолчанию
- **Логин:** `admin`
- **Пароль:** `admin123`

## Стек
- Python 3.12, Django 5.1, DRF 3.17
- Bootstrap 5, vanilla JS
- SQLite (standalone) / PostgreSQL 15 (Docker)
- Redis 7, Django Channels, WebSocket
- Nginx (reverse proxy)

## Автор
yachtsman13 — https://github.com/yachtsman13/Lifteam
