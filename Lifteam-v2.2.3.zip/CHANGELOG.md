# LiftTeam Changelog

## v2.2.4 (hotfix)
- Исправлена ошибка 10061: Redis недоступен в standalone-режиме
- Dev-режим (settings.py) теперь автоматически определяет доступность Redis
- Если Redis не запущен: используется LocMemCache + db-сессии + InMemoryChannelLayer
- Если Redis запущен: используется RedisCache + cache-сессии + RedisChannelLayer
- Standalone-запуск теперь работает без установки Redis

## v2.2.3 (hotfix)
- Исправлена критическая ошибка авторизации: LoginForm не получал данные POST
- LoginForm.__init__ теперь использует kwargs.pop('request') вместо positional arg
- login_view теперь передаёт request=request, data=request.POST явно
- Авторизация по логину admin / пароль admin123 теперь работает корректно

## v2.2.2 (hotfix)
- Исправлен lifteam_launcher.py: правильный вывод логина (admin, не admin@test.com)
- Добавлена диагностика создания пользователей
- Добавлена проверка существования таблицы core_employee
- Добавлена активация пользователя если он неактивен
- Улучшена обработка ошибок при инициализации БД

## v2.2.1 (hotfix)
- Исправлен requirements.txt: `django-channels` → `channels` (правильное название пакета)
- Убран неиспользуемый `djangorestframework-simplejwt`
- Добавлен `asgiref>=3.7` для совместимости Channels

## v2.2.4 (hotfix)
- Исправлена ошибка 10061: Redis недоступен в standalone-режиме
- Dev-режим (settings.py) теперь автоматически определяет доступность Redis
- Если Redis не запущен: используется LocMemCache + db-сессии + InMemoryChannelLayer
- Если Redis запущен: используется RedisCache + cache-сессии + RedisChannelLayer
- Standalone-запуск теперь работает без установки Redis

## v2.2.3 (hotfix)
- Исправлена критическая ошибка авторизации: LoginForm не получал данные POST
- LoginForm.__init__ теперь использует kwargs.pop('request') вместо positional arg
- login_view теперь передаёт request=request, data=request.POST явно
- Авторизация по логину admin / пароль admin123 теперь работает корректно

## v2.2.2 (hotfix)
- Исправлен lifteam_launcher.py: правильный вывод логина (admin, не admin@test.com)
- Добавлена диагностика создания пользователей
- Добавлена проверка существования таблицы core_employee
- Добавлена активация пользователя если он неактивен
- Улучшена обработка ошибок при инициализации БД

## v2.2.1
- Исправлена модель Employee: авторизация по username (логину)
- Исправлен Dockerfile (был сломан — содержал Python-код)
- Исправлен lifteam_launcher.py: версия v2.2, правильные аргументы create_admin
- Списание со склада перенесено из сигналов в явные транзакции views
- Добавлена защита от race condition в генерации номера заказа (select_for_update)
- Исправлена логика истории статусов: создание новой записи вместо обновления старой
- WebSocket теперь активно отправляет обновления остатков
- nginx в docker-compose слушает 0.0.0.0:80 (доступен извне)
- SESSION_COOKIE_SECURE = True в production
- Добавлен --force флаг в create_admin команду
- Обновлены все служебные скрипты до v2.2
